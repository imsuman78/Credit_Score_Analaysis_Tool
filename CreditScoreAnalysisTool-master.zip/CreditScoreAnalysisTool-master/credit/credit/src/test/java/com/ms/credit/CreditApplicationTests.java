package com.ms.credit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditApplicationTests {

	@Test
	void contextLoads() {
	}

}
